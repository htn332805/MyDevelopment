# orchestrator/__init__.py - Minimal version for packaged recipe

"""
Framework0 Orchestrator Package - Minimal Packaged Version

This is a simplified version of the orchestrator package for use in 
packaged recipes. It only includes the essential components needed
for recipe execution.
"""

from orchestrator.context import Context
from orchestrator.runner import run_recipe

__all__ = ["Context", "run_recipe"]
__version__ = "0.1.0"
