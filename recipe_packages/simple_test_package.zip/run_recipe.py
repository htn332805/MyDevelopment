#!/usr/bin/env python3
"""
Portable Recipe Runner

This script provides a standalone execution environment for the packaged recipe.
It can be run independently without requiring the full Framework0 workspace.
"""

import sys
import os
from pathlib import Path

# Add current directory to Python path to find our modules
current_dir = Path(__file__).parent
sys.path.insert(0, str(current_dir))

# Import the orchestrator runner
from orchestrator.runner import run_recipe

def main():
    """Main execution function for the packaged recipe."""
    import argparse
    
    parser = argparse.ArgumentParser(description="Run packaged recipe")
    parser.add_argument("--debug", action="store_true", help="Enable debug logging")
    parser.add_argument("--only", help="Comma-separated list of steps to include")
    parser.add_argument("--skip", help="Comma-separated list of steps to skip")
    
    args = parser.parse_args()
    
    # Parse filters
    only_list = args.only.split(",") if args.only else None
    skip_list = args.skip.split(",") if args.skip else None
    
    # Run the recipe
    recipe_path = current_dir / "recipe.yaml"
    ctx = run_recipe(
        str(recipe_path),
        debug=args.debug,
        only=only_list,
        skip=skip_list
    )
    
    # Print results
    print("Recipe execution completed!")
    print(f"Context keys: {list(ctx.to_dict().keys())}")
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
