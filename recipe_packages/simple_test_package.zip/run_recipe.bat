@echo off
REM Windows batch wrapper for recipe execution
python run_recipe.py %*
